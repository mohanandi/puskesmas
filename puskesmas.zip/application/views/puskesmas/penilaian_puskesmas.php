<div class="site-section" id="menu">
  <div class="container">
    <div class="row mb-5">
      <div class="col-lg-7 mx-auto text-center">
        <span class="subheading">Form Menu</span>
        <h2 class="heading"><strong class="text-primary">Penilaian Puskesmas</strong></h2>
      </div>
    </div>

    <?php if ($data) {
      $link = '';
      $button = 'Simpan Edit';
    } else {
      $link = base_url('Penilaian_Puskesmas/tambah');
      $button = 'Simpan';
    }
    ?>
    <form method="POST" action="<?= $link; ?>" style=" padding:20px;">
      <div class="form-group">
        <label for="exampleFormControlInput1">Melakukan penilaian mandiri (self evaluation) atas ha-sil kinerja & mutu layanan kesehatan yang tercantum dalam Penilaian Kinerja Puskesmas</label>
        <select class="form-control" name="penilaian1" id="penilaian1">
          <?php is_terisi($data['self'], set_value('penilaian1')); ?>
          <option value="Ya">Ya (Bukti Ditunjukkan)</option>
          <option value="Tidak">Tidak</option>
        </select>
        <?= form_error('penilaian1', '<small class="text-danger pl-3">', '</small>'); ?>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Jika Ya, jawab pertanyaan berikut, berapa cakupan kinerja di Tahun (N-2) untuk Hasil Pelayanan Kesehatan Puskesmas</label>
        <select class="form-control" name="penilaian2" id="penilaian2">
          <?php is_terisi($data['n2_pelayanan'], set_value('penilaian2')); ?>
          <option value="1">Baik:(Hasil Pelayanan >91%)</option>
          <option value="2">Cukup:(Hasil Pelayanan >81 - 90%)</option>
          <option value="3">Kurang:(Hasil Pelayanan ≤80%)</option>
        </select>
        <?= form_error('penilaian2', '<small class="text-danger pl-3">', '</small>'); ?>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Jika Ya, jawab pertanyaan berikut, berapa cakupan kinerja di Tahun (N-2) untuk Hasil Manajemen Puskesmas</label>
        <select class="form-control" name="penilaian3" id="penilaian3">
          <?php is_terisi($data['n2_manajemen'], set_value('penilaian3')); ?>
          <option value="1">Baik:(Hasil Pelayanan >8,5%)</option>
          <option value="2">Cukup:(Hasil Pelayanan >5,5 - 8,4%)</option>
          <option value="3">Kurang:(Hasil Pelayanan ≤5,5%)</option>
        </select>
        <?= form_error('penilaian3', '<small class="text-danger pl-3">', '</small>'); ?>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Jika Ya, jawab pertanyaan berikut, berapa Tingkat Kinerja Cakupan, Tahun (N-1) untuk Hasil Pelayanan Kesehatan Puskesmas</label>
        <select class="form-control" name="penilaian4" id="penilaian4">
          <?php is_terisi($data['n1_pelayanan'], set_value('penilaian4')); ?>
          <option value="1">Baik:(Hasil Pelayanan >91%)</option>
          <option value="2">Cukup:(Hasil Pelayanan >81 - 90%)</option>
          <option value="3">Kurang:(Hasil Pelayanan ≤80%)</option>
        </select>
        <?= form_error('penilaian4', '<small class="text-danger pl-3">', '</small>'); ?>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Jika Ya, jawab pertanyaan berikut, berapa Tingkat Kinerja Cakupan, Tahun (N-1) untuk Hasil Manajemen Puskesmas</label>
        <select class="form-control" name="penilaian5" id="penilaian5">
          <?php is_terisi($data['n1_manajemen'], set_value('penilaian5')); ?>
          <option value="1">Baik:(Hasil Pelayanan >8,5%)</option>
          <option value="2">Cukup:(Hasil Pelayanan >5,5 - 8,4%)</option>
          <option value="3">Kurang:(Hasil Pelayanan ≤5,5%)</option>
        </select>
        <?= form_error('penilaian5', '<small class="text-danger pl-3">', '</small>'); ?>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Apakah Saudara melakukan Uji Petik/Monitoring Evaluasi Antar Waktu Untuk Data nomor 2 & nomor 3 di atas, Atas Kinerja & Mutu Layanan Kesehatan Puskesmas Saudara?</label>
        <select class="form-control" name="penilaian6" id="penilaian6">
          <?php is_terisi($data['uji_petik'], set_value('penilaian6')); ?>
          <option value="Ya">Ya</option>
          <option value="Tidak">Tidak</option>
        </select>
        <?= form_error('penilaian6', '<small class="text-danger pl-3">', '</small>'); ?>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Bila jawaban nomor 6 (Ya), apakah Saudara berencana melakukan satu inovasi atas hasil analisis kinerja dan mutu saat saudara melakukan uji petik/monitoring dan evaluasi atas kedua hasil kinerja & mutu layanan Puskesmas Saudara?</label>
        <select class="form-control" name="penilaian7" id="penilaian7">
          <?php is_terisi($data['inovasi'], set_value('penilaian7')); ?>
          <option value="Ya">Ya</option>
          <option value="Tidak">Tidak</option>
        </select>
        <?= form_error('penilaian7', '<small class="text-danger pl-3">', '</small>'); ?>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Bila jawaban nomor 7 (Ya), sebutkan bentuk rumusan upaya Inovasi Saudara?</label><br>
        <select class="form-control" name="penilaian8" id="penilaian8">
          <?php is_terisi($data['rumusan'], set_value('penilaian8')); ?>
          <option value="1">Upaya perbaikan/peningkatan kinerja untuk mencapai target kinerja & mutu layanan Puskesmas pada waktunya</option>
          <option value="2">Upaya percepatan pencapaian target kinerja & mutu layanan Puskesmas sebelum target waktu yg ditetapkan sebelumnya</option>
          <option value="3">ntuk kedua tujuan, Perbaikan/ Peningkatan dan Percepatan </option>
        </select>
        <?= form_error('penilaian8', '<small class="text-danger pl-3">', '</small>'); ?>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Status Akreditasi Puskesmas Terakhir, Sebutkan Tahun ………</label>
        <input type="text" class="form-control" value="<?= set_value('penilaian9') ?>" placeholder="tahun" name="penilaian9" id="penilaian9">
        <?= form_error('penilaian9', '<small class="text-danger pl-3">', '</small>'); ?>
        <select class="form-control" name="penilaian10" id="penilaian10">
          <?php is_terisi($data['status_akreditas'], set_value('penilaian10')); ?>
          <option value="1">Madya</option>
          <option value="2">Utama</option>
          <option value="3">Paripurna</option>
        </select>
        <?= form_error('penilaian10', '<small class="text-danger pl-3">', '</small>'); ?>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Status IKS Puskesmas Terakhir, Sebutkan Tahun ...</label>
        <input type="text" class="form-control" value="<?= set_value('penilaian11') ?>" placeholder="tahun" name="penilaian11" id="penilaian11">
        <?= form_error('penilaian10', '<small class="text-danger pl-3">', '</small>'); ?>
        <select class="form-control" name="penilaian12" id="penilaian12">
          <?php is_terisi($data['status_iks'], set_value('penilaian12')); ?>
          <option value="1"> >0,800</option>
          <option value="2"> 0,500-0,800</option>
          <option value="3"> 0,500 </option>
        </select> <?= form_error('penilaian12', '<small class="text-danger pl-3">', '</small>'); ?> </div>
      <button type="submit" class="btn float-right btn-success" style="color: white; margin-left:10px; margin-top:5px; border-radius:5px;"><?= $button; ?></button>
    </form>
  </div>
</div>