<link rel="stylesheet" type="text/css" href="<?= base_url('assets/') ?>css/tooltip.css">
      <div class="col-md-9">


        <form style="height:350px; overflow-y:auto; padding:20px;">
		<div class="alert alert-success" role="alert">
							Data Berhasil dimasukan !
						</div>
							<div class="form-group">
							 <label for="exampleFormControlInput1">Nomor izin operasional Puskesmas</label>
							  <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="" name="organisasi1" id="organisasi1" value="" readonly>
							</div>
 <div class="form-group">
            <div class="con">
           
              <div class="row">
                <div class="col-md-4">
                  <label for="exampleFormControlInput1"><strong> No. </strong></label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1"><strong> Parameter </strong></label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1"><strong>Nilai Akhir </strong></label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">1.</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">PEMENUHAN SUMBER DAYA</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">Skor diperoleh dibagi 80 dikali 100%</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">2.</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">PERENCANAAN PUSKESMAS</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">Skor diperoleh dibagi 290 dikali 100%</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">3.</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">PELAKSANAAN KEGIATAN PUSKESMAS</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">Skor diperoleh dibagi 60 dikali 100%</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">4.</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">PENILAIAN KINERJA PUSKESMAS</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">Skor diperoleh dibagi 20 dikali 100%</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">5.</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">PENINGKATAN MUTU PUSKESMAS</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">Skor diperoleh dibagi 50 dikali 100%</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">6.</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">PENCEGAHAN DAN PENGENDALIAN INFEKSI</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">Skor diperoleh dibagi 120 dikali 100%</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">7.</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">PELAKSANAAN SKDR TERHADAP PENYAKIT MENULAR POTENSIAL KLB/WABAH</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">Skor diperoleh dibagi 30 dikali 100%</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">8.</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">CAKUPAN INDIKATOR PROGRAM</label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">Skor diperoleh dibagi 160 dikali 100%</label>

                </div>
              </div>
            </div>
			<br>
			   <label for="exampleFormControlInput1"><strong>Kesimpulan Nilai Akhir: (Lingkari salah satu penilaian)</strong><br>1. Baik<br>2. Cukup<br>3. Kurang</label>
            </div>
            <div class="form-group">
              <label for="exampleFormControlInput1"><strong>Interpretasi<br>1. Baik, bila setiap parameter bernilai ≥ 80%</strong><br>2. Cukup, bila ada satu atau dua parameter bernilai 61% - 79% dan parameter yang lain bernilai ≥ 80%.<br>3. Kurang, bila tidak memenuhi kriteria 1 dan 2</label>
            </div><br>
            <div class="form-group">
			  </form>

      </div>
		
    </div>


  </div>
</div>
</div>
</div>
</div>

<script src="<?= base_url('assets/') ?>js/tooltip.js"></script>
<script src="<?= base_url('assets/') ?>js/para.js"></script>
