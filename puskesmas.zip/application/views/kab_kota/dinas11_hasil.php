<link rel="stylesheet" type="text/css" href="<?= base_url('assets/') ?>css/tooltip.css">


      <div class="col-md-9">


        <form style="height:350px; overflow-y:auto; padding:20px;">
		<div class="alert alert-success" role="alert">
							Data Berhasil dimasukan !
						</div>
							<div class="form-group">
							 <label for="exampleFormControlInput1">Nomor izin operasional Puskesmas</label>
							  <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="" name="organisasi1" id="organisasi1" value="" readonly>
							</div>
          <div class="form-group">

            <div class="con">
              <div class="row">
                <div class="col-md-4">
                  <label for="exampleFormControlInput1"><strong>NO.</strong></label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1"><strong>RENCANA TINDAK LANJUT</strong></label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1"><strong>TANGGAL PELAKSANAAN</strong></label>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">1.</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="" name="rencana1" id="rencana1" value="" readonly>
                </div>
                <div class="col-md-4">
                  <input type="date" class="form-control" id="exampleFormControlInput1" placeholder="" name="rencanatgl1" id="rencanatgl1" value="" readonly>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">2.</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="" name="rencana2" id="rencana2" value="" readonly>
                </div>
                <div class="col-md-4">
                  <input type="date" class="form-control" id="exampleFormControlInput1" placeholder="" name="rencanatgl2" id="rencanatgl2" value="" readonly>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">3.</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="" name="rencana3" id="rencana3" value="" readonly>
                </div>
                <div class="col-md-4">
                  <input type="date" class="form-control" id="exampleFormControlInput1" placeholder="" name="rencanatgl3" id="rencanatgl3" value="" readonly>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">4.</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="" name="rencana4" id="rencana4" value="" readonly>
                </div>
                <div class="col-md-4">
                  <input type="date" class="form-control" id="exampleFormControlInput1" placeholder="" name="rencanatgl4" id="rencanatgl4" value="" readonly>
                </div>
                <div class="col-md-4">
                  <label for="exampleFormControlInput1">5.</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="DST" name="rencana5" id="rencana5" value="" readonly>
                </div>
                <div class="col-md-4"> 
                  <input type="date" class="form-control" id="exampleFormControlInput1" placeholder="DST" name="rencanatgl5" id="rencanatgl5" value="" readonly>
                </div>
              </div>
            </div>
          </div>
        </form>
        <a class="btn float-right btn-success" href="table.html" style="color: white; margin-left:10px; margin-top:5px; border-radius:5px;">Masukan</a>
        <a class="btn float-right btn-danger" href="#" style="color: white; margin-left:10px; margin-top:5px;border-radius:5px;">Hapus</a>

      </div>

    </div>


  </div>
</div>
</div>
</div>
</div>

<script src="<?= base_url('assets/') ?>js/tooltip.js"></script>
<script src="<?= base_url('assets/') ?>js/para.js"></script>
