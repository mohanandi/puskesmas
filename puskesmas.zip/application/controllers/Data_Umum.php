<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_Umum extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }
    public function data_umum_hasil()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum_hasil');
        $this->load->view('templates/puskesmas/foot');
    }

	 public function data_umum1()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum1');
        $this->load->view('templates/puskesmas/foot');
    }

	 public function data_umum2()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum2');
        $this->load->view('templates/puskesmas/foot');
    }

		 public function data_umum3()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum3');
        $this->load->view('templates/puskesmas/foot');
    }

		 public function data_umum4()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum4');
        $this->load->view('templates/puskesmas/foot');
    }

		 public function data_umum5()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum5');
        $this->load->view('templates/puskesmas/foot');
    }

		 public function data_umum6()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum6');
        $this->load->view('templates/puskesmas/foot');
    }

		 public function data_umum7()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum7');
        $this->load->view('templates/puskesmas/foot');
    }

		 public function data_umum8()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum8');
        $this->load->view('templates/puskesmas/foot');
    }

	 public function data_umum8_hasil()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum8_hasil');
        $this->load->view('templates/puskesmas/foot');
    }

	public function data_umum6_hasil()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum6_hasil');
        $this->load->view('templates/puskesmas/foot');
    }

	public function data_umum5_hasil()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum5_hasil');
        $this->load->view('templates/puskesmas/foot');
    }

	public function data_umum7_hasil()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum7_hasil');
        $this->load->view('templates/puskesmas/foot');
    }

	public function data_umum4_hasil()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum4_hasil');
        $this->load->view('templates/puskesmas/foot');
    }

	public function data_umum3_hasil()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum3_hasil');
        $this->load->view('templates/puskesmas/foot');
    }

	public function data_umum1_hasil()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum1_hasil');
        $this->load->view('templates/puskesmas/foot');
    }

	public function data_umum2_hasil()
    {
        $this->load->view('templates/puskesmas/head');
        $this->load->view('puskesmas/data_umum2_hasil');
        $this->load->view('templates/puskesmas/foot');
    }


}
