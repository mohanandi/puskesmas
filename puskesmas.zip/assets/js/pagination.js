$(document).ready(function() {
    $('#example').DataTable( {
        "scrollX": true
    } );
    
} );